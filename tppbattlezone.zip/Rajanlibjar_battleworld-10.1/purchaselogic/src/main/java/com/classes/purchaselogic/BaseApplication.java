package com.classes.purchaselogic;

import android.app.Application;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public abstract class BaseApplication extends Application {

    // Creating JSON Parser object
    private final JSONParser jsonParser = new JSONParser();

    // JSON Node names
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_RAJANR = "rajanr";

    // products JSONArray
    private JSONArray jsonarray = null;

    private int success;

    private static BaseApplication a;

    public BaseApplication() {
        a = this;
    }

    public static Context getContext() {
        return a;
    }

    public abstract String getPurchaseCode();

    public abstract String getEmail();

    private NotificationManager notificationManager;
    public static final String NOTIFICATION_CHANNEL_ID = "4655";
    public static final String NOTIFICATION_CHANNEL_NAME = "NAME4655";

    public void onCreate() {
        super.onCreate();
//        Kozuza.a(this, this.getPurchaseCode(), this.getProduct());
//        Toast.makeText(a, "Get Purchage code"+ this.getPurchaseCode(), Toast.LENGTH_SHORT).show();

        new OneLoadAllProducts().execute();

    }

    private class OneLoadAllProducts extends AsyncTask<String, String, String> {

        /**
         * Before starting background thread Show Progress Dialog
         * */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /**
         * getting All products from url
         * */
        protected String doInBackground(String... args) {
            // Building Parameters
            Map<String, String> params = new HashMap<>();
            params.put("packagename", getApplicationContext().getPackageName());
            params.put("purchagecode", getPurchaseCode());

            // getting JSON string from URL

            // Check your log cat for JSON reponse
//            System.out.println("Rajan_json"+json);

            try {
                // Checking for SUCCESS TAG
                success = json.getInt(TAG_SUCCESS);

//                newversion = json.getString("newversion");

                if("purchagecode"=='7dcf59e0-36dc-46d2-8136-30049fa8578c') {
//                    System.out.println("Rajan_pkg_success");
                } else {
//                    System.out.println("Rajan_pkg_not_valid");
                }

            } catch (JSONException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        /**
         * After completing background task Dismiss the progress dialog
         * **/
        protected void onPostExecute(String file_url) {

//            // updating UI from Background Thread
//            runOnUiThread(new Runnable() {
//                public void run() {
                    /*
                      Updating parsed JSON data into ListView
                     */
                    if (success == 1) {
                        // jsonarray found
                        // Getting Array of jsonarray

                    } else if (success == 2){
                        /*
                          Updating parsed JSON data into ListView
                         */

                        try {
                            System.out.println("Rajan_codecanyon");

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

//                }
//            });

        }

    }
}
